/**
 * The SeriesTV class extends the Media class
 * and is an abstract data type that contains data related to a TV Series.
 * Objects of this class type do not contain episode or season information. 
 * 
 */
public class SeriesTV extends Media{
	
	String title;
	Integer year;
	Integer endYear;
	
	/**
	 * Constructor for the SeriesTV class.
	 * 
	 * @param title TV Series title.
	 * @param year  Year the series started.
	 * @param venue Year the series was completed.
	 */
	public SeriesTV(String title, Integer year, Integer endYear) {
		super(title, year);
		this.endYear = endYear;
	}
	
	/**
	 * Allows the user to access the endYear variable
	 * @return Year the series was completed
	 */
	public Integer getEndYear() {
		return endYear;
	}
	
	/**
	 * Returns a formatted String of the SeriesTV object.
	 */
	@Override
	public String toString() {
		return "";
	}

	/**
	 * This abstract method that returns a String indicating that the object is a SeriesTV object.
	 * The method will be used in mediaDB to determine whether to return the object after a search.
	 */
	@Override
	public String getMediaType() {
		return "TV SERIES";
	}
}
