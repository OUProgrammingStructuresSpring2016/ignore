import static org.junit.Assert.*;

import org.junit.Test;

import mDB.Movie;

public class mediaDBTest {

	@Test
	public void testParseMovie() {
		String test1 = "'Star Trek: Deep Space Nine': Behind the Scenes (1993) (V)  1993";
		Movie movie1 = new Movie("'Star Trek: Deep Space Nine': Behind the Scenes", new Integer(1993), "V"); 
		assertEquals(parseMovie(test1).compareTo(movie1), 0);
		
		String test2 = "America Loves... Star Trek (2001) (TV)          2001";
		Movie movie2 = new Movie("America Loves... Star Trek", 2001, "TV");
		assertEquals(parseMovie(test2).compareTo(movie2), 0);
		
		String test3 = "Star Trek 4 (????)                  ????";
		Movie movie3 = new Movie("Star Trek 4", 0, "");
		assertEquals(parseMovie(test3).compareTo(movie3), 0);
		
		String test4 = "'Weird Al' Yankovic: (There's No) Going Home (1996) (TV) 1996";
		Movie movie4 = new Movie("'Weird Al' Yankovic: (There's No) Going Home", 1996, "TV");
		assertEquals(parseMovie(test4).compareTo(movie4), 0);
		
		String test5 = "Pitch Perfect II (2015)                   2015";
		Movie movie5 = new Movie("Pitch Perfect II", 2015, "");
		assertEquals(parseMovie(test5).compareTo(movie5), 0);
		
		String test6 = "Black Beauty (1921/I) 1921";
		Movie movie6 = new Movie("Black Beauty", 1921, "");
		assertEquals(parseMovie(test6).compareTo(movie6), 0);
	}

	@Test
	public void testParseTV() {
		String t1 = "'Doctor Who' (1963)                 1963-1989";
		SeriesTV m1 = new SeriesTV("Doctor Who", new Integer(1963), new Integer(1989));
		assertEquals(compareTo(t1, m1), 0);
		
		String t2 = "'Doctor Who' (2005)                 2005-???? ";
		SeriesTV m2 = new SeriesTV("Doctor Who", new Integer(2005), new Integer(0));
		assertEquals(compareTo(t2, m2), 0);
		
		String t3 = "'Doctor Who' (1963) {A Bargain of Necessity (#1.41)}    1964 ";
		EpisodeTV m3 = new EpisodeTV("Doctor Who", new Integer(1963), "A Bargain of Necessity", 1, 41, new Integer(1964), false);
		assertEquals(compareTo(t3, m3), 0);
		
		String t4 = "'Doctor Who' (1963) {Blink} {{SUSPENDED}}       ???? ";
		EpisodeTV m4 = new EpisodeTV("Doctor Who", new Integer(1963), "Blink", 0, 0, new Integer(0), true); 
		assertEquals(compareTo(t4, m4), 0);
		
		String t5 = "'Doctor Who' (2005) {A Ghost Story for Christmas}   2009";
		EpisodeTV m5 = new EpisodeTV("Doctor Who", new Integer(2005), "A Ghost Story for Christmas", 0, 0, new Integer(2009), false);
		assertEquals(compareTo(t5, m5), 0);
		
		
		
	}

}
