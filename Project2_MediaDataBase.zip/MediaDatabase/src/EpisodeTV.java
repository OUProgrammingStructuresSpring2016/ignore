/**
 * The EpisodeTV class extends the Media class
 * and is an abstract data type that contains data related to episodes of a TV Series.
 * Objects of this class type DO contain episode and season information. 
 * 
 */
public class EpisodeTV extends Media {

	String title;
	Integer year;
	String episodeTitle;
	int seasonNumber;
	int episodeNumber;
	Integer episodeReleaseYear;
	boolean suspended;
	
	/**
	 * Constructor for EpisodeTV class.
	 * @param title Title of the TV Series.
	 * @param year  Year the TV Series first aired.
	 * @param episodeTitle Title of the episode.
	 * @param seasonNumber Season when the episode aired.
	 * @param episodeNumber The episode number.
	 * @param episodeReleaseYear Year when the episode was released.
	 * @param suspended Whether the episode was suspended.
	 */
	public EpisodeTV(String title, Integer year, String episodeTitle, int seasonNumber, int episodeNumber, 
			Integer episodeReleaseYear, boolean suspended) {
		super(title, year);
		this.episodeTitle = episodeTitle;
		this.seasonNumber = seasonNumber;
		this.episodeNumber = episodeNumber;
		this.episodeReleaseYear = episodeReleaseYear;
		this.suspended = suspended;
	}
	
	/**
	 * 
	 * @return episodeTitle
	 */
	public String getEpisodeTitle() {
		return episodeTitle;
	}
	
	/**
	 * 
	 * @return seasonNumber
	 */
	public int getSeasonNumber() {
		return seasonNumber;
	}
	
	/**
	 * 
	 * @return episodeNumber
	 */
	public int getEpisodeNumber() {
		return episodeNumber;
	}
	
	/**
	 * 
	 * @return episodeReleaseYear
	 */
	public Integer getEpisodeReleaseYear() {
		return episodeReleaseYear;
	}
	
	/**
	 * Indicator of whether the episode was suspended.
	 * @return getSuspended
	 */
	public boolean getSuspended() {
		return suspended;
	}
	
	/**
	 * Returns a formatted string of the EpisodeTV object.
	 */
	@Override
	public String toString() {
		return "";
	}
	
	/**
	 * This abstract method that returns a String indicating that the object is a EpisodeTV object.
	 * The method will be used in mediaDB to determine whether to return the object after a search.
	 */
	@Override
	public String getMediaType() {
		return "TV EPISODE";
	}

}
