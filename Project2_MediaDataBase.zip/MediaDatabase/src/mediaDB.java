import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Project #2
 * CS 2334, Section 13
 * February 19, 2016
 * <P>
 * The mediaDB class provides several static methods to import/export files, parse files, store data,
 * and provides a menu interface for the user to access the database/program.
 * 
 * @author Alexandra Amidon
 *
 */
public class mediaDB {
	
	/**
	 * This method reads in a file, loops through all lines and runs either parseMovie() or parseTV() on the line,
	 * and inserts the Media object into the mediaList. 
	 * 
	 * @param mediaList The list to insert parsed objects into
	 */
	public static void readFile(List<Movie> mediaList) {
		return;
	}
	
	/**
	 * This method parses lines from a file into a Movie object.
	 * 
	 * @param line The String inputed by the readFile() method
	 * @return A Movie object.
	 */
	public static Movie parseMovie(String line) {
		return null;
	}
	
	/**
	 * This method parses lines from a file into an EpisodeTV or SeriesTV object.
	 * 
	 * @param line The String inputed by the readFile() method
	 * @return An EpisodeTV or SeriesTV object
	 */
	public static Media parseTV(String line) {
		return null;
	}
	
	/**
	 * This method takes in a list of Media objects and writes them into a file.
	 * 
	 * @param mediaList A list of Media objects that the user wishes to save to a file.
	 * @param NewFileName The location where the user wants the data stored.
	 * @throws IOException
	 */
	public static void writeFile(List<Media> mediaList, String NewFileName) throws IOException {
		return;
	}
	
	/**
	 * This method sorts a Media list according to the default settings.
	 * @param l
	 */
	public static void sortList(List<Media> l) {
		Collections.sort(l);
		return;
	}
	
	/**
	 * This method sorts a Media list according to other optional settings, as described by the Comparator object
	 * @param l
	 * @param c
	 */
	public static void sortList(List<Media> l, Comparator c) {
		Collections.sort(l, c);
		return;
	}
	
	/**
	 * This method searches the media list by the input title.
	 * @param l The media list to search
	 * @param title Title to search by.
	 * @param exact A boolean variable indicating whether the user wants to conduct an exact search
	 * @return
	 */
	public static Media searchList(List<Media> l, String title, boolean exact) {
		
		return null;
	}
	
	/**
	 * This method searches the media list by the input title and year.
	 * @param l The media list to search
	 * @param title Title to search by.
	 * @param year Year to search by.
	 * @param exact A boolean variable indicating whether the user wants to conduct an exact search
	 * @return
	 */
	public static Media searchList(List<Media> l, Integer year, boolean exact) {
		return null;
	}
	
	/**
	 * Helper method to the menu method. It submits a String query to the user and returns the user response.
	 * 
	 * @param br BufferedReader object used to read in user input.  
	 * @param query The String that the programmer would like to send to the user.
	 * @return The user response.
	 */
	private static String getUserInput(BufferedReader br, String query) {
		return "";
	}
	
	/**
	 * This method allows the program to interact with the user to determine the users's desired search parameters,
	 * calls the appropriate search, returns the results, and saves the results at the user's request.
	 *  
	 * @param mediaList
	 */
	public static void menu(List<Media> mediaList) {
		BufferedReader inputReader = new BufferedReader( new InputStreamReader( System.in ) ); 
		
		return;
	}
	
	
	
	public static void main(String args[]) {
		List<Media> mediaList;
		
		
	}
}
