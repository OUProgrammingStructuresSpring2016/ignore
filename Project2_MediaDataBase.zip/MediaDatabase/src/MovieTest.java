import static org.junit.Assert.*;

import org.junit.Test;

public class MovieTest {

	@Test
	public void testToString() {
		Movie movie1 = new Movie("'Star Trek: Deep Space Nine': Behind the Scenes", new Integer(1993), "V"); 
		Movie movie2 = new Movie("America Loves... Star Trek", 2001, "TV");
		Movie movie3 = new Movie("Star Trek 4", 0, "");
		Movie movie4 = new Movie("'Weird Al' Yankovic: (There's No) Going Home", 1996, "TV");
		Movie movie6 = new Movie("Black Beauty", 1921, "");
		
		assertEquals(movie1.toString(), "MOVIE (straight to video): 'Star Trek: Deep Space Nine': Behind the Scenes (1993)");
		assertEquals(movie2.toString(), "MOVIE (TV): America Loves... Star Trek (2001)");
		assertEquals(movie3.toString(), "MOVIE: Star Trek 4 (UNSPECIFIED)");
		assertEquals(movie4.toString(), "MOVIE (TV): 'Weird Al' Yankovic: (There's No) Going Home (1996)");
		assertEquals(movie6.toString(), "MOVIE: Black Beauty (1921)");
	}

}
