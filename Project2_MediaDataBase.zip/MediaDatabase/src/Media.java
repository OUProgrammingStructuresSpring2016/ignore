import java.util.Comparator;

/**
 * The Media class is an abstract data type that stores, returns, and compares basic data related to any type of media.
 * 
 * 
 */

public abstract class Media implements Comparable<Media> {
	private String title;
	private Integer year;
	
	/**
	 * Media object constructor 
	 * @param title Media title (String).
	 * @param year  The year a Movie was released or the year a TV Series started (Integer).
	 */
	public Media(String title, Integer year) {
		this.title = title;
		this.year = year;
	}
	
	/**
	 * The getTitle() method returns the Media object title.
	 * @return The Media object title (String).
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * The getYear() method returns the Movie release year or TV Series start year.
	 * @return The Movie release year or TV Series start year (Integer).
	 */
	public Integer getYear() {
		return year;
	}
	
	/**
	 * Abstract method that returns a String of the Media object.
	 */
	@Override
	public abstract String toString();
	
	/**
	 * Abstract method that returns a String indicating the object type.
	 * The method will be used in mediaDB to determine whether to return the object after a search.
	 */
	public abstract String getMediaType();
	
	/** 
	 * Overrides the default Comparable compareTo method. 
	 * The default comparison is by Media title, then year.
	 */
	@Override
	public int compareTo(Media m) {
		//TODO Write method
		return -1;
	}
	
	/**
	 * The inner class creates a Comparator<Media> object with the ability to compare Media objects by year.
	 */
	private class yearComparator implements Comparator<Media> {

		@Override
		public int compare(Media m1, Media m2) {
			// TODO Write method
			return 0;
		}
	}
	
}
