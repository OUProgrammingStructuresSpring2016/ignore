
/**
 * The Movie class extends the Media class
 * and is an abstract data type that contains data related to movies. 
 * 
 */
public class Movie extends Media {
	
	private String title;
	private Integer year;
	private String venue; 
	
	/**
	 * Constructor for the Movie class.
	 * 
	 * @param title Movie title.
	 * @param year  Year the movie was released.
	 * @param venue Venue the movie was released in ((movie theatre, TV, or video)).
	 */
	public Movie(String title, Integer year, String venue) {
		super(title, year);
		
		this.title = title;
		this.year = year;
		this.venue = venue;
	}
	
	/**
	 * Allows the user to access the getVenue variable.
	 * @return Venue the movie was released in.
	 */
	public String getVenue() {
		return venue;
	}
	
	/**
	 * Returns a formatted string of the Movie object
	 */
	@Override
	public String toString() {
		return "";
	}
	
	/**
	 * This abstract method that returns a String indicating that the object is a Movie object.
	 * The method will be used in mediaDB to determine whether to return the object after a search.
	 */
	@Override
	public String getMediaType() {
		return "MOVIE";
	}
}
