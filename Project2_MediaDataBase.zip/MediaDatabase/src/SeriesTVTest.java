import static org.junit.Assert.*;

import org.junit.Test;

public class SeriesTVTest {

	@Test
	public void testToString() {
		SeriesTV m1 = new SeriesTV("Doctor Who", new Integer(1963), new Integer(1989));
		SeriesTV m2 = new SeriesTV("Doctor Who", new Integer(2005), new Integer(0));
		
		assertEquals(m1.toString(), "SERIES: Doctor Who (1963-1989)");
		assertEquals(m1.toString(), "SERIES: Doctor Who (2005-UNSPECIFIED)");
	}

}
