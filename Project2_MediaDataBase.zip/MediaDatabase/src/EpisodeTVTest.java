import static org.junit.Assert.*;

import org.junit.Test;

public class EpisodeTVTest {

	@Test
	public void testToString() {
		EpisodeTV m3 = new EpisodeTV("Doctor Who", new Integer(1963), "A Bargain of Necessity", 1, 41, new Integer(1964), false);
		EpisodeTV m4 = new EpisodeTV("Doctor Who", new Integer(1963), "Blink", 0, 0, new Integer(0), true);
		EpisodeTV m5 = new EpisodeTV("Doctor Who", new Integer(2005), "A Ghost Story for Christmas", 0, 0, new Integer(2009), false);
		
		assertEquals(m3.toString(), "EPISODE: Doctor Who: A Bargain of Necessity (1964)");
		assertEquals(m4.toString(), "EPISODE: Doctor Who: Blink (UNSPECIFIED)");
		assertEquals(m5.toString(), "EPISODE: Doctor Who: A Ghost Story for Christmas (2004)");
	}

}
